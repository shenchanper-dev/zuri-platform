'use client';

import { useState } from 'react';
import { 
  exportToExcel, 
  exportFilteredToExcel, 
  ExcelColumn 
} from '@/utils/export/excelExport';
import { 
  printTable, 
  printRecord 
} from '@/utils/export/printExport';
import { 
  exportToPDF, 
  exportSingleToPDF, 
  PDFColumn 
} from '@/utils/export/pdfExport';
import { 
  shareViaWhatsApp, 
  generateShareText 
} from '@/utils/export/whatsappShare';
import { 
  sendEmail, 
  copyToClipboard 
} from '@/utils/export/emailSend';

/**
 * COMPONENTE GLOBAL: Botones de Exportación/Compartir
 * Reutilizable para cualquier módulo
 */

export interface ExportConfig {
  moduleName: string;
  title: string;
  data: any[];
  columns: { header: string; key: string; width?: number }[];
  singleItem?: {
    title: string;
    fields: { label: string; value: string }[];
  };
}

interface ExportActionsProps {
  config: ExportConfig;
  variant?: 'full' | 'compact';
  onExportStart?: () => void;
  onExportComplete?: (type: string, success: boolean) => void;
}

export default function ExportActions({ 
  config, 
  variant = 'full',
  onExportStart,
  onExportComplete 
}: ExportActionsProps) {
  const [loading, setLoading] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(false);

  // ──────────────────────────────────────────────────────────
  // HANDLER: Exportar a Excel
  // ──────────────────────────────────────────────────────────
  const handleExportExcel = async () => {
    setLoading('excel');
    onExportStart?.();

    const result = await exportFilteredToExcel(
      config.moduleName,
      config.data,
      config.columns as ExcelColumn[]
    );

    setLoading(null);
    onExportComplete?.('excel', result.success);

    if (result.success) {
      alert('✅ Excel descargado correctamente');
    } else {
      alert('❌ Error al exportar: ' + result.error);
    }
  };

  // ──────────────────────────────────────────────────────────
  // HANDLER: Exportar a PDF
  // ──────────────────────────────────────────────────────────
  const handleExportPDF = async () => {
    setLoading('pdf');
    onExportStart?.();

    const fecha = new Date().toLocaleDateString('es-PE');
    
    let result;
    if (config.singleItem) {
      result = await exportSingleToPDF(
        config.singleItem.title,
        config.singleItem.fields,
        `${config.moduleName}_${fecha}`
      );
    } else {
      result = await exportToPDF({
        title: config.title,
        subtitle: `Total de registros: ${config.data.length}`,
        columns: config.columns.map(col => ({
          header: col.header,
          dataKey: col.key
        })) as PDFColumn[],
        data: config.data,
        filename: `${config.moduleName}_${fecha}`,
        orientation: config.columns.length > 5 ? 'landscape' : 'portrait'
      });
    }

    setLoading(null);
    onExportComplete?.('pdf', result.success);

    if (result.success) {
      alert('✅ PDF descargado correctamente');
    } else {
      alert('❌ Error al exportar: ' + result.error);
    }
  };

  // ──────────────────────────────────────────────────────────
  // HANDLER: Compartir por WhatsApp
  // ──────────────────────────────────────────────────────────
  const handleShareWhatsApp = () => {
    setLoading('whatsapp');
    onExportStart?.();

    let text: string;
    
    if (config.singleItem) {
      text = generateShareText(
        config.singleItem.title,
        config.singleItem.fields
      );
    } else {
      text = `*${config.title}*\n\n`;
      text += `Total de registros: ${config.data.length}\n\n`;
      
      config.data.slice(0, 5).forEach((item, idx) => {
        const firstCol = config.columns[0].key;
        text += `${idx + 1}. ${item[firstCol]}\n`;
      });
      
      if (config.data.length > 5) {
        text += `\n...y ${config.data.length - 5} más`;
      }
      
      text += `\n\n_Compartido desde ZURI - ${new Date().toLocaleDateString('es-PE')}_`;
    }

    const result = shareViaWhatsApp({ text });

    setLoading(null);
    onExportComplete?.('whatsapp', result.success);
  };

  // ──────────────────────────────────────────────────────────
  // HANDLER: Imprimir
  // ──────────────────────────────────────────────────────────
  const handlePrint = () => {
    setLoading('print');
    onExportStart?.();

    let result;
    
    if (config.singleItem) {
      result = printRecord(
        config.singleItem.title,
        config.singleItem.fields
      );
    } else {
      result = printTable(
        config.title,
        config.columns.map(col => ({
          header: col.header,
          key: col.key
        })),
        config.data
      );
    }

    setLoading(null);
    onExportComplete?.('print', result.success);

    if (!result.success) {
      alert('❌ Error al imprimir: ' + result.error);
    }
  };

  // ──────────────────────────────────────────────────────────
  // RENDER: Botón reutilizable
  // ──────────────────────────────────────────────────────────
  const Button = ({ 
    onClick, 
    icon, 
    label, 
    color, 
    isLoading 
  }: { 
    onClick: () => void; 
    icon: string; 
    label: string; 
    color: string;
    isLoading: boolean;
  }) => (
    <button
      type="button"  /* ← AGREGADO: Previene submit del form */
      onClick={onClick}
      disabled={isLoading}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        padding: '10px 16px',
        backgroundColor: isLoading ? '#d1d5db' : color,
        color: 'white',
        border: 'none',
        borderRadius: '6px',
        fontSize: '14px',
        fontWeight: '500',
        cursor: isLoading ? 'not-allowed' : 'pointer',
        transition: 'all 0.2s',
        opacity: isLoading ? 0.6 : 1
      }}
      onMouseEnter={(e) => {
        if (!isLoading) {
          e.currentTarget.style.opacity = '0.9';
          e.currentTarget.style.transform = 'translateY(-1px)';
        }
      }}
      onMouseLeave={(e) => {
        if (!isLoading) {
          e.currentTarget.style.opacity = '1';
          e.currentTarget.style.transform = 'translateY(0)';
        }
      }}
    >
      <span style={{ fontSize: '18px' }}>{icon}</span>
      <span>{isLoading ? 'Procesando...' : label}</span>
    </button>
  );

  if (variant === 'compact') {
    // Versión compacta: Menú desplegable
    return (
      <div style={{ position: 'relative' }}>
        <button
          type="button"  /* ← AGREGADO: Previene submit del form */
          onClick={() => setShowMenu(!showMenu)}
          style={{
            padding: '8px 16px',
            backgroundColor: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          📤 Exportar ▼
        </button>
        
        {showMenu && (
          <div style={{
            position: 'absolute',
            top: '100%',
            left: 0,  /* ← CAMBIADO: de right a left */
            marginTop: '8px',
            backgroundColor: 'white',
            border: '1px solid #e5e7eb',
            borderRadius: '8px',  /* ← AUMENTADO: de 6px a 8px */
            boxShadow: '0 10px 25px rgba(0,0,0,0.15)',  /* ← MEJORADO: más sombra */
            zIndex: 10000,  /* ← AUMENTADO: de 1000 a 10000 */
            minWidth: '200px',
            overflow: 'hidden'  /* ← AGREGADO */
          }}>
            {[
              { onClick: handleExportExcel, icon: '📊', label: 'Excel', key: 'excel' },
              { onClick: handleExportPDF, icon: '📄', label: 'PDF', key: 'pdf' },
              { onClick: handleShareWhatsApp, icon: '💬', label: 'WhatsApp', key: 'whatsapp' },
              { onClick: handlePrint, icon: '🖨️', label: 'Imprimir', key: 'print' }
            ].map(btn => (
              <button
                type="button"
                key={btn.key}
                onClick={() => {
                  btn.onClick();
                  setShowMenu(false);
                }}
                disabled={loading !== null}
                style={{
                  width: '100%',
                  padding: '14px 20px',  /* ← AUMENTADO: de 12px 16px */
                  border: 'none',
                  backgroundColor: 'transparent',
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  fontSize: '14px',
                  fontWeight: '500',  /* ← AGREGADO */
                  transition: 'background-color 0.2s',
                  borderBottom: '1px solid #f3f4f6'  /* ← AGREGADO: separador */
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f0f9ff'}  /* ← CAMBIADO: color más claro */
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <span style={{ fontSize: '20px' }}>{btn.icon}</span>  {/* ← AUMENTADO: de 18px */}
                <span>{btn.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Versión completa: 4 botones
  return (
    <div style={{ 
      display: 'flex', 
      gap: '12px', 
      flexWrap: 'wrap',
      alignItems: 'center'
    }}>
      <Button
        onClick={handleExportExcel}
        icon="📊"
        label="Excel"
        color="#10b981"
        isLoading={loading === 'excel'}
      />
      <Button
        onClick={handleExportPDF}
        icon="📄"
        label="PDF"
        color="#ef4444"
        isLoading={loading === 'pdf'}
      />
      <Button
        onClick={handleShareWhatsApp}
        icon="💬"
        label="WhatsApp"
        color="#25d366"
        isLoading={loading === 'whatsapp'}
      />
      <Button
        onClick={handlePrint}
        icon="🖨️"
        label="Imprimir"
        color="#8b5cf6"
        isLoading={loading === 'print'}
      />
    </div>
  );
}
