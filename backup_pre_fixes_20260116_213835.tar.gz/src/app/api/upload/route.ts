import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';

export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;

        if (!file) {
            return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
        }

        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        // ✅ RUTA REAL AL PUBLIC (Usando process.cwd() para entorno VPS/Producción)
        const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'conductores');

        try {
            await mkdir(uploadDir, { recursive: true });
        } catch (error) {
            // El directorio ya existe o error controlado
        }

        // Generar nombre limpio y único
        const timestamp = Date.now();
        const cleanName = file.name.replace(/\.[^/.]+$/, "").replace(/\s+/g, "_").replace(/[^a-z0-9_]/gi, '');
        const extension = path.extname(file.name).toLowerCase() || '.jpg';
        const filename = `${timestamp}-${cleanName}${extension}`;

        // Guardar físicamente
        const filepath = path.join(uploadDir, filename);
        await writeFile(filepath, buffer);

        // ✅ URL PÚBLICA (Next.js sirve /public/X como /X)
        const publicUrl = `/uploads/conductores/${filename}`;

        console.log(`✅ Archivo guardado en: ${filepath}`);
        console.log(`🔗 URL pública: ${publicUrl}`);

        return NextResponse.json({
            success: true,
            url: publicUrl,
            fileUrl: publicUrl // Mantenemos fileUrl por compatibilidad temporal
        });
    } catch (error) {
        console.error('❌ Error en upload:', error);
        return NextResponse.json({ error: 'Error al procesar la subida' }, { status: 500 });
    }
}