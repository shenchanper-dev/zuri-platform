// src/app/api/conductores/route.ts
// API CONDUCTORES - CORREGIDO PARA POSTGRESQL REAL
// Sistema ZURI NEMT - Compatible con tabla real de 35+ campos
// ✅ NOMBRES DE COLUMNAS CORREGIDOS (PostgreSQL con camelCase)

import { NextRequest, NextResponse } from 'next/server';
import { Client } from 'pg';

// INTERFACE EXACTA SEGÚN TABLA REAL
export interface ConductorReal {
  id?: number;
  dni: string;
  nombres: string;
  apellidos: string;
  fechaNacimiento?: string;
  celular1: string;
  celular2?: string;
  email?: string;
  estadoCivil?: string;
  numeroHijos?: number;
  domicilioCompleto?: string;
  domicilioDistrito?: string;
  domicilioLatitud?: number;
  domicilioLongitud?: number;
  nombreContactoEmergencia?: string;
  celularContactoEmergencia?: string;
  numeroBrevete: string;
  fechaVencimientoBrevete?: string;
  marcaVehiculo?: string;
  modeloVehiculo?: string;
  placa?: string;
  añoVehiculo?: number;
  capacidadPasajeros?: number;
  tipoVehiculo?: string;
  estado?: string;
  observaciones?: string;
  fechaIngreso?: string;
  ubicacionActualLatitud?: number;
  ubicacionActualLongitud?: number;
  ultimaActualizacionGPS?: string;
  precisionGPS?: number;
  velocidadActual?: number;
  rumboActual?: number;
  nivelBateria?: number;
  estaConectado?: boolean;
  ultimaConexion?: string;
  modoTracking?: string;
  createdAt?: string;
  updatedAt?: string;
}

const dbConfig = {
  connectionString: 'postgresql://postgres@localhost:5432/zuri_db'
};

// GET: Obtener conductores
export async function GET() {
  let client: Client | null = null;

  try {
    console.log('🔍 [API-Conductores] Iniciando consulta...');

    client = new Client(dbConfig);
    await client.connect();

    // ✅ Query CORREGIDA - La tabla PostgreSQL preserva camelCase con comillas
    const query = `
      SELECT 
        id,
        dni,
        nombres,
        apellidos,
        "fechaNacimiento",
        foto,
        celular1,
        celular2,
        email,
        "estadoCivil",
        "numeroHijos",
        "domicilioCompleto",
        "domicilioDistrito",
        "domicilioLatitud",
        "domicilioLongitud",
        "nombreContactoEmergencia",
        "celularContactoEmergencia",
        "numeroBrevete",
        "fechaVencimientoBrevete",
        "marcaVehiculo",
        "modeloVehiculo",
        placa,
        "añoVehiculo",
        "capacidadPasajeros",
        "tipoVehiculo",
        estado,
        observaciones,
        "fechaIngreso",
        "ubicacionActualLatitud",
        "ubicacionActualLongitud",
        "ultimaActualizacionGPS",
        "precisionGPS",
        "velocidadActual",
        "rumboActual",
        "nivelBateria",
        "estaConectado",
        "ultimaConexion",
        "modoTracking",
        "fotoVehiculo",
        "distrito_id",
        servicios,
        equipamiento
      FROM conductores 
      ORDER BY id DESC
    `;

    const result = await client.query(query);
    console.log(`✅ [API-Conductores] Encontrados: ${result.rows.length} conductores`);

    const conductores = result.rows.map(row => ({
      id: row.id,
      dni: row.dni,
      nombres: row.nombres,
      apellidos: row.apellidos,
      nombreCompleto: `${row.nombres} ${row.apellidos}`.trim(),
      foto: row.foto || null,
      fotoVehiculo: row.fotoVehiculo || null,
      fechaNacimiento: row.fechaNacimiento ? new Date(row.fechaNacimiento).toISOString().split('T')[0] : null,
      celular1: row.celular1,
      celular2: row.celular2,
      email: row.email,
      estadoCivil: row.estadoCivil,
      numeroHijos: row.numeroHijos || 0,
      domicilioCompleto: row.domicilioCompleto,
      domicilioDistrito: row.domicilioDistrito,
      distrito_id: row.distrito_id,
      domicilioLatitud: row.domicilioLatitud ? parseFloat(row.domicilioLatitud) : null,
      domicilioLongitud: row.domicilioLongitud ? parseFloat(row.domicilioLongitud) : null,
      nombreContactoEmergencia: row.nombreContactoEmergencia,
      celularContactoEmergencia: row.celularContactoEmergencia,
      numeroBrevete: row.numeroBrevete,
      fechaVencimientoBrevete: row.fechaVencimientoBrevete ? new Date(row.fechaVencimientoBrevete).toISOString().split('T')[0] : null,
      marcaVehiculo: row.marcaVehiculo,
      modeloVehiculo: row.modeloVehiculo,
      placa: row.placa,
      placaVehiculo: row.placa, // Compatibilidad
      añoVehiculo: row.añoVehiculo,
      añoAuto: row.añoVehiculo, // Compatibilidad
      capacidadPasajeros: row.capacidadPasajeros,
      tipoVehiculo: row.tipoVehiculo,
      estado: row.estado,
      observaciones: row.observaciones,
      servicios: row.servicios || [],
      equipamiento: row.equipamiento || []
    }));

    // Estadísticas reales
    const stats = {
      total: conductores.length,
      activos: conductores.filter(c => (c as any).estado === 'ACTIVO').length,
      conectados: conductores.filter(c => (c as any).estaConectado).length,
      conVehiculo: conductores.filter(c => (c as any).marcaVehiculo).length,
      conGPS: conductores.filter(c => (c as any).ubicacionActualLatitud && (c as any).ubicacionActualLongitud).length
    };

    return NextResponse.json({
      conductores,
      stats,
      success: true
    });

  } catch (error) {
    console.error('❌ [API-Conductores] Error en GET:', error);
    return NextResponse.json(
      {
        error: error.message,
        success: false,
        codigo_error: 'CONDUCTOR_GET_ERROR'
      },
      { status: 500 }
    );
  } finally {
    if (client) {
      await client.end();
    }
  }
}

// POST: Crear conductor
export async function POST(request: NextRequest) {
  let client: Client | null = null;

  try {
    const contentType = request.headers.get('content-type') || '';
    let body: any = {};
    let filesToSave: { name: string, file: File }[] = [];

    // ✅ SOPORTE PARA FORM DATA (Subida directa de fotos)
    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData();
      formData.forEach((value, key) => {
        if (value instanceof File) {
          filesToSave.push({ name: key, file: value });
        } else {
          try {
            // Intentar parsear si es un array/objeto serializado
            body[key] = JSON.parse(value.toString());
          } catch {
            body[key] = value.toString();
          }
        }
      });
    } else {
      body = await request.json();
    }

    // ✅ GUARDAR ARCHIVOS SI EXISTEN
    if (filesToSave.length > 0) {
      const { writeFile, mkdir } = await import('fs/promises');
      const path = await import('path');
      const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'conductores');

      try { await mkdir(uploadDir, { recursive: true }); } catch { }

      for (const item of filesToSave) {
        const timestamp = Date.now();
        const cleanName = item.file.name.replace(/\.[^/.]+$/, "").replace(/\s+/g, "_").replace(/[^a-z0-9_]/gi, '');
        const extension = path.extname(item.file.name).toLowerCase() || '.jpg';
        const filename = `${timestamp}-${cleanName}${extension}`;
        const filepath = path.join(uploadDir, filename);

        const bytes = await item.file.arrayBuffer();
        await writeFile(filepath, Buffer.from(bytes));

        body[item.name] = `/api/uploads/conductores/${filename}`;
        console.log(`📸 Archivo ${item.name} guardado en: ${body[item.name]}`);
      }
    }

    // Normalización de campos comunes
    const placa = body.placa || body.placaVehiculo || body.numeroPlaca || null;
    const domicilioCompleto = body.domicilioCompleto || body.direccionCompleta || null;
    const distrito_id = body.distrito_id ? parseInt(body.distrito_id) : null;

    console.log('💾 [API-Conductores] Creando conductor DNI:', body.dni);

    // Validaciones básicas
    if (!body.dni || body.dni.length !== 8) {
      return NextResponse.json({ error: 'DNI inválido', success: false }, { status: 400 });
    }

    client = new Client(dbConfig);
    await client.connect();

    // Verificar DNI único
    const existingCheck = await client.query('SELECT id FROM conductores WHERE dni = $1', [body.dni]);
    if (existingCheck.rows.length > 0) {
      return NextResponse.json({ error: 'DNI ya existe', success: false }, { status: 400 });
    }

    const insertQuery = `
      INSERT INTO conductores (
        dni, nombres, apellidos, "fechaNacimiento", foto, celular1, celular2, email, "estadoCivil", "numeroHijos",
        "domicilioCompleto", "domicilioDistrito", distrito_id, "domicilioLatitud", "domicilioLongitud",
        "nombreContactoEmergencia", "celularContactoEmergencia", "numeroBrevete", "fechaVencimientoBrevete",
        "marcaVehiculo", "modeloVehiculo", placa, "añoVehiculo", "capacidadPasajeros", "tipoVehiculo",
        estado, observaciones, "fechaIngreso", "fotoVehiculo", "licencia_categoria", "soatVencimiento",
        "revisionTecnicaVencimiento", "colorAuto", servicios, equipamiento
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
        $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
        $21, $22, $23, $24, $25, $26, $27, $28, $29, $30,
        $31, $32, $33, $34, $35
      ) RETURNING id
    `;

    const insertValues = [
      body.dni, body.nombres, body.apellidos, body.fechaNacimiento || null, body.foto || null,
      body.celular1, body.celular2 || null, body.email || null, body.estadoCivil || null, body.numeroHijos || 0,
      domicilioCompleto, body.domicilioDistrito || null, distrito_id, body.domicilioLatitud || null, body.domicilioLongitud || null,
      body.nombreContactoEmergencia || null, body.celularContactoEmergencia || null, body.numeroBrevete, body.fechaVencimientoBrevete || null,
      body.marcaVehiculo || body.marcaAuto || null, body.modeloVehiculo || body.modeloAuto || null, placa, body.añoVehiculo || body.añoAuto || null,
      body.capacidadPasajeros || 4, body.tipoVehiculo || 'SEDAN', body.estado || 'ACTIVO', body.observaciones || null,
      body.fechaIngreso || new Date().toISOString().split('T')[0], body.fotoVehiculo || null,
      body.licencia_categoria || null, body.soatVencimiento || null, body.revisionTecnicaVencimiento || null, body.colorAuto || null,
      JSON.stringify(body.servicios || []), JSON.stringify(body.equipamiento || [])
    ];

    const result = await client.query(insertQuery, insertValues);

    return NextResponse.json({
      success: true,
      id: result.rows[0].id,
      message: 'Conductor creado exitosamente'
    }, { status: 201 });

  } catch (error: any) {
    console.error('❌ [API-Conductores] Error:', error);
    return NextResponse.json({ error: error.message, success: false }, { status: 500 });
  } finally {
    if (client) await client.end();
  }
}
