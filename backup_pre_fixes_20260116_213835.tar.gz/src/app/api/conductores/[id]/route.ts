// src/app/api/conductores/[id]/route.ts
// OPERACIONES INDIVIDUALES CONDUCTORES - LIMPIO SIN DUPLICACIONES
// ✅ Solo nombres y apellidos como campos separados
// ✅ nombreCompleto se genera automáticamente

import { NextRequest, NextResponse } from 'next/server';
import { Client } from 'pg';

const dbConfig = {
  connectionString: 'postgresql://postgres@localhost:5432/zuri_db'
};

// GET: Obtener conductor por ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  let client: Client | null = null;

  try {
    const id = parseInt(params.id);
    console.log(`🔍 [GET] Obteniendo conductor ID: ${id}`);

    if (isNaN(id)) {
      return NextResponse.json(
        { error: 'ID inválido', success: false },
        { status: 400 }
      );
    }

    client = new Client(dbConfig);
    await client.connect();

    // ✅ Query usando nombres de columnas EXACTOS como están en tu BD
    const query = `
      SELECT 
        id, dni, nombres, apellidos, "fechaNacimiento", foto, celular1, celular2,
        email, "estadoCivil", "numeroHijos", "domicilioCompleto", "domicilioDistrito",
        distrito_id, "domicilioLatitud", "domicilioLongitud", "nombreContactoEmergencia",
        "celularContactoEmergencia", "numeroBrevete", "fechaVencimientoBrevete",
        "marcaVehiculo", "modeloVehiculo", placa, "añoVehiculo", "capacidadPasajeros",
        "tipoVehiculo", estado, observaciones, "fechaIngreso",
        "ubicacionActualLatitud", "ubicacionActualLongitud", "ultimaActualizacionGPS",
        "precisionGPS", "velocidadActual", "rumboActual", "nivelBateria",
        "estaConectado", "ultimaConexion", "modoTracking", "createdAt", "updatedAt",
        servicios, equipamiento, "fotoVehiculo", "licencia_categoria",
        "soatVencimiento", "revisionTecnicaVencimiento", "colorAuto"
      FROM conductores 
      WHERE id = $1
    `;

    const result = await client.query(query, [id]);

    if (result.rows.length === 0) {
      return NextResponse.json(
        { error: 'Conductor no encontrado', success: false },
        { status: 404 }
      );
    }

    const row = result.rows[0];

    // ✅ Mapeo SIMPLE - solo concatenar nombres + apellidos
    const conductor = {
      id: row.id,
      dni: row.dni,
      nombres: row.nombres,
      apellidos: row.apellidos,
      nombreCompleto: `${row.nombres} ${row.apellidos}`.trim(), // ✅ SIMPLE
      fechaNacimiento: row.fechaNacimiento ? new Date(row.fechaNacimiento).toISOString().split('T')[0] : null,
      foto: row.foto,
      celular1: row.celular1,
      celular2: row.celular2,
      email: row.email,
      estadoCivil: row.estadoCivil,
      numeroHijos: row.numeroHijos || 0,
      domicilioCompleto: row.domicilioCompleto,
      domicilioDistrito: row.domicilioDistrito,
      distrito_id: row.distrito_id,
      domicilioLatitud: row.domicilioLatitud ? parseFloat(row.domicilioLatitud) : null,
      domicilioLongitud: row.domicilioLongitud ? parseFloat(row.domicilioLongitud) : null,
      // Aliases for frontend compatibility
      direccionCompleta: row.domicilioCompleto,
      latitud: row.domicilioLatitud ? parseFloat(row.domicilioLatitud) : null,
      longitud: row.domicilioLongitud ? parseFloat(row.domicilioLongitud) : null,
      nombreContactoEmergencia: row.nombreContactoEmergencia,
      celularContactoEmergencia: row.celularContactoEmergencia,
      numeroBrevete: row.numeroBrevete,
      fechaVencimientoBrevete: row.fechaVencimientoBrevete ? new Date(row.fechaVencimientoBrevete).toISOString().split('T')[0] : null,
      marcaVehiculo: row.marcaVehiculo,
      modeloVehiculo: row.modeloVehiculo,
      placa: row.placa,
      numeroPlaca: row.placa, // ✅ Mapeo para frontend
      añoVehiculo: row.añoVehiculo,
      capacidadPasajeros: row.capacidadPasajeros || 4,
      tipoVehiculo: row.tipoVehiculo || 'SEDAN',
      estado: row.estado || 'ACTIVO',
      observaciones: row.observaciones,
      fechaIngreso: row.fechaIngreso ? new Date(row.fechaIngreso).toISOString().split('T')[0] : null,
      ubicacionActualLatitud: row.ubicacionActualLatitud ? parseFloat(row.ubicacionActualLatitud) : null,
      ubicacionActualLongitud: row.ubicacionActualLongitud ? parseFloat(row.ubicacionActualLongitud) : null,
      ultimaActualizacionGPS: row.ultimaActualizacionGPS ? new Date(row.ultimaActualizacionGPS).toISOString() : null,
      precisionGPS: row.precisionGPS ? parseFloat(row.precisionGPS) : null,
      velocidadActual: row.velocidadActual ? parseFloat(row.velocidadActual) : 0,
      rumboActual: row.rumboActual || 0,
      nivelBateria: row.nivelBateria || 100,
      estaConectado: row.estaConectado || false,
      ultimaConexion: row.ultimaConexion ? new Date(row.ultimaConexion).toISOString() : null,
      modoTracking: row.modoTracking || 'MANUAL',
      // ✅ NUEVOS CAMPOS NEMT
      servicios: row.servicios || [],
      equipamiento: row.equipamiento || [],
      fotoVehiculo: row.fotoVehiculo || null,
      licencia_numero: row.numeroBrevete, // ✅ Alias para frontend
      licencia_categoria: row.licencia_categoria,
      marcaAuto: row.marcaVehiculo, // ✅ Alias para frontend
      modeloAuto: row.modeloVehiculo, // ✅ Alias para frontend
      placaVehiculo: row.placa, // ✅ Alias para frontend
      añoAuto: row.añoVehiculo, // ✅ Alias para frontend
      colorAuto: row.colorAuto,
      soatVencimiento: row.soatVencimiento ? new Date(row.soatVencimiento).toISOString().split('T')[0] : null,
      revisionTecnicaVencimiento: row.revisionTecnicaVencimiento ? new Date(row.revisionTecnicaVencimiento).toISOString().split('T')[0] : null,
      createdAt: row.createdAt ? new Date(row.createdAt).toISOString() : null,
      updatedAt: row.updatedAt ? new Date(row.updatedAt).toISOString() : null
    };

    console.log(`✅ [GET] Conductor encontrado: ${conductor.nombreCompleto}, foto: ${conductor.foto ? 'SÍ' : 'NO'}`);

    return NextResponse.json({
      conductor,
      success: true
    });

  } catch (error) {
    console.error('❌ [GET] Error al obtener conductor:', error);
    return NextResponse.json(
      { error: `Error interno: ${error.message}`, success: false },
      { status: 500 }
    );
  } finally {
    if (client) {
      await client.end();
    }
  }
}

// PUT: Actualizar conductor
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  let client = null;
  try {
    const id = parseInt(params.id);
    if (isNaN(id)) return NextResponse.json({ error: 'ID inválido', success: false }, { status: 400 });

    console.log(`🔄 [PUT] Actualizando conductor ID: ${id}`);

    const contentType = request.headers.get('content-type') || '';
    let body: any = {};
    let filesToSave: { name: string, file: File }[] = [];

    // ✅ SOPORTE PARA FORM DATA
    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData();
      formData.forEach((value, key) => {
        if (value instanceof File) {
          filesToSave.push({ name: key, file: value });
        } else {
          try {
            body[key] = JSON.parse(value.toString());
          } catch {
            body[key] = value.toString();
          }
        }
      });
    } else {
      body = await request.json();
    }

    const { Client } = await import('pg');
    client = new Client(dbConfig);
    await client.connect();

    // 1️⃣ OBTENER DATOS ACTUALES
    const currentResult = await client.query('SELECT * FROM conductores WHERE id = $1', [id]);
    if (currentResult.rows.length === 0) {
      await client.end();
      return NextResponse.json({ error: 'Conductor no encontrado', success: false }, { status: 404 });
    }
    const currentData = currentResult.rows[0];

    // 2️⃣ GUARDAR ARCHIVOS SI EXISTEN
    if (filesToSave.length > 0) {
      const { writeFile, mkdir } = await import('fs/promises');
      const path = await import('path');
      const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'conductores');
      try { await mkdir(uploadDir, { recursive: true }); } catch { }

      for (const item of filesToSave) {
        const timestamp = Date.now();
        const cleanName = item.file.name.replace(/\.[^/.]+$/, "").replace(/\s+/g, "_").replace(/[^a-z0-9_]/gi, '');
        const extension = path.extname(item.file.name).toLowerCase() || '.jpg';
        const filename = `${timestamp}-${cleanName}${extension}`;
        const filepath = path.join(uploadDir, filename);

        const bytes = await item.file.arrayBuffer();
        await writeFile(filepath, Buffer.from(bytes));

        body[item.name] = `/api/uploads/conductores/${filename}`;
      }
    }

    // Normalización de campos
    const nombres = body.nombres !== undefined ? body.nombres : currentData.nombres;
    const apellidos = body.apellidos !== undefined ? body.apellidos : currentData.apellidos;
    const placa = body.placa || body.placaVehiculo || body.numeroPlaca || currentData.placa;
    const domicilioCompleto = body.domicilioCompleto || body.direccionCompleta || currentData.domicilioCompleto;

    // ✅ UPDATE
    const query = `
      UPDATE conductores SET
        dni = $1, nombres = $2, apellidos = $3, "fechaNacimiento" = $4, foto = $5,
        celular1 = $6, celular2 = $7, email = $8, "estadoCivil" = $9, "numeroHijos" = $10,
        "domicilioCompleto" = $11, "domicilioDistrito" = $12, distrito_id = $13, "domicilioLatitud" = $14, "domicilioLongitud" = $15,
        "nombreContactoEmergencia" = $16, "celularContactoEmergencia" = $17, "numeroBrevete" = $18, "fechaVencimientoBrevete" = $19,
        "marcaVehiculo" = $20, "modeloVehiculo" = $21, placa = $22, "añoVehiculo" = $23, "capacidadPasajeros" = $24,
        "tipoVehiculo" = $25, estado = $26, observaciones = $27, "fechaIngreso" = $28, "fotoVehiculo" = $29,
        "licencia_categoria" = $30, "soatVencimiento" = $31, "revisionTecnicaVencimiento" = $32, "colorAuto" = $33,
        servicios = $34, equipamiento = $35, "updatedAt" = NOW()
      WHERE id = $36
      RETURNING *
    `;

    // ✅ LOGS DE DEPURACIÓN
    console.log(`📸 [PUT] Foto recibida: ${body.foto || 'vacia'}`);
    console.log(`📸 [PUT] FotoVehiculo recibida: ${body.fotoVehiculo || 'vacia'}`);

    const values = [
      body.dni !== undefined ? body.dni : currentData.dni,
      nombres,
      apellidos,
      body.fechaNacimiento !== undefined ? body.fechaNacimiento : currentData.fechaNacimiento,
      (body.foto && body.foto !== '') ? body.foto : currentData.foto,
      body.celular1 !== undefined ? body.celular1 : currentData.celular1,
      body.celular2 !== undefined ? body.celular2 : currentData.celular2,
      body.email !== undefined ? body.email : currentData.email,
      body.estadoCivil !== undefined ? body.estadoCivil : currentData.estadoCivil,
      body.numeroHijos !== undefined ? body.numeroHijos : currentData.numeroHijos,
      domicilioCompleto,
      body.domicilioDistrito !== undefined ? body.domicilioDistrito : currentData.domicilioDistrito,
      body.distrito_id !== undefined ? parseInt(body.distrito_id) : currentData.distrito_id,
      body.domicilioLatitud !== undefined ? body.domicilioLatitud : currentData.domicilioLatitud,
      body.domicilioLongitud !== undefined ? body.domicilioLongitud : currentData.domicilioLongitud,
      body.nombreContactoEmergencia !== undefined ? body.nombreContactoEmergencia : currentData.nombreContactoEmergencia,
      body.celularContactoEmergencia !== undefined ? body.celularContactoEmergencia : currentData.celularContactoEmergencia,
      body.numeroBrevete !== undefined ? body.numeroBrevete : currentData.numeroBrevete,
      body.fechaVencimientoBrevete !== undefined ? body.fechaVencimientoBrevete : currentData.fechaVencimientoBrevete,
      body.marcaVehiculo !== undefined ? body.marcaVehiculo : (body.marcaAuto !== undefined ? body.marcaAuto : currentData.marcaVehiculo),
      body.modeloVehiculo !== undefined ? body.modeloVehiculo : (body.modeloAuto !== undefined ? body.modeloAuto : currentData.modeloVehiculo),
      placa,
      body.añoVehiculo !== undefined ? body.añoVehiculo : (body.añoAuto !== undefined ? body.añoAuto : currentData.añoVehiculo),
      body.capacidadPasajeros !== undefined ? body.capacidadPasajeros : currentData.capacidadPasajeros,
      body.tipoVehiculo !== undefined ? body.tipoVehiculo : currentData.tipoVehiculo,
      body.estado !== undefined ? body.estado : currentData.estado,
      body.observaciones !== undefined ? body.observaciones : currentData.observaciones,
      body.fechaIngreso !== undefined ? body.fechaIngreso : currentData.fechaIngreso,
      (body.fotoVehiculo && body.fotoVehiculo !== '') ? body.fotoVehiculo : currentData.fotoVehiculo,
      body.licencia_categoria !== undefined ? body.licencia_categoria : currentData.licencia_categoria,
      body.soatVencimiento !== undefined ? body.soatVencimiento : currentData.soatVencimiento,
      body.revisionTecnicaVencimiento !== undefined ? body.revisionTecnicaVencimiento : currentData.revisionTecnicaVencimiento,
      body.colorAuto !== undefined ? body.colorAuto : currentData.colorAuto,
      body.servicios !== undefined ? JSON.stringify(body.servicios) : currentData.servicios,
      body.equipamiento !== undefined ? JSON.stringify(body.equipamiento) : currentData.equipamiento,
      id
    ];

    console.log(`📝 [PUT] Usando foto actual: ${values[4] === currentData.foto ? 'SÍ' : 'NO (NUEVA)'}`);
    console.log(`📝 [PUT] Usando foto vehículo actual: ${values[28] === currentData.fotoVehiculo ? 'SÍ' : 'NO (NUEVA)'}`);

    await client.query(query, values);

    return NextResponse.json({ success: true, message: 'Conductor actualizado correctamente' });

  } catch (error: any) {
    console.error('❌ [PUT] Error:', error);
    return NextResponse.json({ error: error.message, success: false }, { status: 500 });
  } finally {
    if (client) await client.end();
  }
}

// DELETE: Eliminar conductor (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  let client: Client | null = null;

  try {
    const id = parseInt(params.id);
    console.log(`🗑️ [DELETE] Eliminando conductor ID: ${id}`);

    if (isNaN(id)) {
      return NextResponse.json(
        { error: 'ID inválido', success: false },
        { status: 400 }
      );
    }

    client = new Client(dbConfig);
    await client.connect();

    // Verificar que existe
    const existsCheck = await client.query(
      'SELECT id, nombres, apellidos, estado FROM conductores WHERE id = $1',
      [id]
    );

    if (existsCheck.rows.length === 0) {
      return NextResponse.json(
        { error: 'Conductor no encontrado', success: false },
        { status: 404 }
      );
    }

    const conductor = existsCheck.rows[0];

    // ✅ Soft delete - cambiar estado
    await client.query(
      'UPDATE conductores SET estado = $1, "updatedAt" = NOW() WHERE id = $2',
      ['ELIMINADO', id]
    );

    console.log(`✅ [DELETE] Conductor eliminado: ${conductor.nombres} ${conductor.apellidos}`);

    return NextResponse.json({
      success: true,
      message: 'Conductor eliminado exitosamente'
    });

  } catch (error) {
    console.error('❌ [DELETE] Error al eliminar conductor:', error);
    return NextResponse.json(
      { error: `Error interno: ${error.message}`, success: false },
      { status: 500 }
    );
  } finally {
    if (client) {
      await client.end();
    }
  }
}