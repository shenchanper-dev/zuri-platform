#!/bin/bash
# Script de Restauración Automática Zuri Platform

echo "🚀 Iniciando Restauración del Sistema..."

# Verificar si se ejecuta como root (para instalaciones) o usuario normal
if [ "$EUID" -eq 0 ]; then 
  echo "⚠️  Por favor no ejecute este script como root. Ejecútelo como el usuario que manejará la aplicación (ej: ubuntu)."
  exit 1
fi

PROJECT_ROOT=$(pwd)

# 1. Restaurar Código
echo "📂 Restaurando código fuente..."
rsync -av code/ ./zuri-platform/

# 2. Restaurar DB
echo "🗄️ Restaurando base de datos..."
# Preguntar credenciales si es necesario
read -p "Ingrese nombre de usuario de base de datos (default: zuri): " DB_USER
DB_USER=${DB_USER:-zuri}
read -p "Ingrese nombre de base de datos (default: zuri_db): " DB_NAME
DB_NAME=${DB_NAME:-zuri_db}

# Crear DB si no existe
createdb -U postgres $DB_NAME 2>/dev/null || echo "La DB ya existe o requiere password de postgres"
psql -U $DB_USER -d $DB_NAME < db/zuri_db.sql

# 3. Instalar Dependencias y Build
echo "📦 Instalando dependencias..."
cd zuri-platform
npm install
echo "🏗️ Construyendo aplicación..."
npm run build

# 4. Configurar Nginx
echo "🌍 Configuración de Nginx disponible en config/"
echo "   Copie config/admin.zuri.pe.nginx a /etc/nginx/sites-available/"
echo "   y cree el enlace simbólico."

echo "✅ Restauración completada."
echo "   Para iniciar: cd zuri-platform && pm2 start npm --name zuri-platform -- start"
